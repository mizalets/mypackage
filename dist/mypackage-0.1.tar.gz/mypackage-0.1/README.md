# mypackage
This library is created as an example from EDSA of  how to publish one's own Python package.

## building this package locally
`python setup.py sdidt`

## installing this package from GitHub
`pip install git+https://github.com/Nakedi-Letsoalo/example-python-package.git`

## updating this package from Github`
`pip install --upgrade git+https://github.com/Nakedi-Letsoalo/example-python-package.git`
